import SwiftUI
import FocusDockCore

private let accent = Color(red: 0.20, green: 0.66, blue: 0.49)

struct DockView: View {
    @ObservedObject var controller: PanelWindowController
    @ObservedObject var repository: TaskRepository
    @State private var filter = TaskFilter.active

    var body: some View {
        Group {
            if controller.interaction.isExpanded { expanded } else { capsule }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: controller.interaction.isExpanded ? 24 : 25))
        .overlay {
            RoundedRectangle(cornerRadius: controller.interaction.isExpanded ? 24 : 25)
                .strokeBorder(.primary.opacity(0.09), lineWidth: 1)
                .allowsHitTesting(false)
        }
        .clipShape(RoundedRectangle(cornerRadius: controller.interaction.isExpanded ? 24 : 25))
        .preferredColorScheme(controller.theme.colorScheme)
        .tint(accent)
        .alert("操作未完成", isPresented: Binding(get: { controller.errorMessage != nil }, set: { if !$0 { controller.errorMessage = nil } })) {
            Button("好", role: .cancel) { controller.errorMessage = nil }
        } message: { Text(controller.errorMessage ?? "") }
    }

    private var capsule: some View {
        HStack(spacing: 9) {
            brandMark(size: 24)
            Text("FocusDock").font(.system(size: 13, weight: .semibold, design: .rounded))
            Text("\(activeItems.count)").font(.system(size: 11, weight: .bold, design: .rounded))
                .foregroundStyle(accent).padding(.horizontal, 6).padding(.vertical, 3)
                .background(accent.opacity(0.12), in: Capsule())
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .contentShape(Capsule())
        .overlay(DragRegion(controller: controller, onClick: { controller.togglePin() }))
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("FocusDock，\(activeItems.count) 项待办")
        .accessibilityAddTraits(.isButton)
        .accessibilityAction { controller.togglePin() }
        .help("悬停展开 · 点击锁定 · 拖动移动")
    }

    private var expanded: some View {
        VStack(spacing: 0) {
            header
            Divider().opacity(0.5)
            if let editor = controller.editor {
                TaskEditorView(session: editor, controller: controller).id(editor.id)
            } else {
                taskList
            }
        }
    }

    private var header: some View {
        HStack(spacing: 10) {
            HStack(spacing: 10) {
                brandMark(size: 29)
                VStack(alignment: .leading, spacing: 1) {
                    Text("FocusDock").font(.system(size: 15, weight: .semibold, design: .rounded))
                    Text("给专注留一点空间").font(.system(size: 10)).foregroundStyle(.secondary)
                }
                Spacer(minLength: 0)
            }
            .overlay(DragRegion(controller: controller))
            .help("拖动以移动悬浮窗")
            Button { controller.togglePin() } label: {
                Image(systemName: controller.interaction.isPinned ? "pin.fill" : "pin")
                    .foregroundStyle(controller.interaction.isPinned ? accent : .secondary)
            }
            .help(controller.interaction.isPinned ? "取消锁定" : "锁定展开")
            .accessibilityLabel(controller.interaction.isPinned ? "取消锁定" : "锁定展开")
            Button { controller.collapse() } label: { Image(systemName: "minus") }
                .disabled(controller.editor != nil).help("收起").accessibilityLabel("收起")
        }
        .buttonStyle(.plain)
        .padding(.horizontal, 20).frame(height: 68)
    }

    private var taskList: some View {
        VStack(alignment: .leading, spacing: 14) {
            TimelineView(.periodic(from: .now, by: 60)) { context in
                VStack(alignment: .leading, spacing: 5) {
                    HStack(alignment: .firstTextBaseline) {
                        Text("我的待办").font(.system(size: 25, weight: .bold, design: .rounded))
                        Spacer()
                        Text(context.date, format: .dateTime.month().day()).font(.system(size: 11)).foregroundStyle(.secondary)
                    }
                    let overdue = activeItems.filter { ($0.dueDate ?? .distantFuture) < context.date }.count
                    Text(overdue > 0 ? "\(activeItems.count) 项待办 · \(overdue) 项已逾期" : "\(activeItems.count) 项待办，按自己的节奏完成")
                        .font(.system(size: 12)).foregroundStyle(overdue > 0 ? Color.orange : .secondary)
                }
            }
            Picker("待办筛选", selection: $filter) {
                ForEach(TaskFilter.allCases) { Text($0.rawValue).tag($0) }
            }.pickerStyle(.segmented).labelsHidden()

            if filteredItems.isEmpty {
                VStack(spacing: 11) {
                    Image(systemName: filter == .completed ? "checkmark.seal" : "sun.max")
                        .font(.system(size: 36, weight: .light)).foregroundStyle(accent)
                    Text(filter == .completed ? "完成的事，会留在这里" : "留白，也是一种进展")
                        .font(.system(size: 15, weight: .medium))
                    Text(filter == .completed ? "勾选一项待办，就能看到它。" : "从一件小事开始，记下你的下一步。")
                        .font(.system(size: 12)).foregroundStyle(.secondary)
                }.frame(maxWidth: .infinity, maxHeight: .infinity)
            } else {
                ScrollView {
                    LazyVStack(spacing: 9) {
                        ForEach(filteredItems) { item in TaskRow(item: item, controller: controller) }
                    }.padding(.vertical, 2)
                }.scrollIndicators(.hidden)
            }

            Button { controller.beginEditing() } label: {
                Label("添加待办", systemImage: "plus")
                    .font(.system(size: 13, weight: .semibold))
                    .frame(maxWidth: .infinity).padding(.vertical, 12)
            }
            .buttonStyle(.plain).foregroundStyle(.white)
            .background(accent.gradient, in: RoundedRectangle(cornerRadius: 12))
            HStack(spacing: 4) {
                Image(systemName: "internaldrive")
                Text("仅保存在这台 Mac")
                Spacer()
                if controller.interaction.isPinned { Label("已锁定", systemImage: "pin.fill") }
            }.font(.system(size: 10)).foregroundStyle(.tertiary)
        }.padding(20)
    }

    private var activeItems: [TodoItem] { repository.items.filter { !$0.isCompleted } }
    private var filteredItems: [TodoItem] {
        repository.items.filter {
            switch filter { case .active: return !$0.isCompleted; case .completed: return $0.isCompleted; case .all: return true }
        }
    }
    private func brandMark(size: CGFloat) -> some View {
        Image(systemName: "checkmark").font(.system(size: size * 0.46, weight: .bold))
            .foregroundStyle(.white).frame(width: size, height: size)
            .background(accent.gradient, in: RoundedRectangle(cornerRadius: size * 0.34))
    }
}

private enum TaskFilter: String, CaseIterable, Identifiable {
    case active = "待完成", completed = "已完成", all = "全部"
    var id: String { rawValue }
}

private struct TaskRow: View {
    let item: TodoItem
    @ObservedObject var controller: PanelWindowController
    var body: some View {
        HStack(alignment: .top, spacing: 10) {
            Button { controller.toggle(item) } label: {
                Image(systemName: item.isCompleted ? "checkmark.circle.fill" : "circle")
                    .font(.system(size: 20, weight: .light))
                    .foregroundStyle(item.isCompleted ? accent : .secondary)
            }.buttonStyle(.plain).accessibilityLabel(item.isCompleted ? "标记未完成：\(item.title)" : "完成：\(item.title)")
            Button { controller.beginEditing(item) } label: {
                VStack(alignment: .leading, spacing: 7) {
                    Text(item.title).font(.system(size: 13, weight: .medium))
                        .strikethrough(item.isCompleted).foregroundStyle(item.isCompleted ? .secondary : .primary)
                        .lineLimit(2).multilineTextAlignment(.leading)
                    if !item.notes.isEmpty {
                        Text(item.notes).font(.system(size: 11)).foregroundStyle(.secondary).lineLimit(1)
                    }
                    HStack(spacing: 7) {
                        if item.priority != .normal {
                            Label(item.priority.title, systemImage: "flag.fill")
                                .foregroundStyle(item.priority == .high ? Color.orange : .secondary)
                        }
                        if let date = item.dueDate {
                            TimelineView(.periodic(from: .now, by: 60)) { timeline in
                                Label(date.formatted(.dateTime.month().day().hour().minute()), systemImage: "clock")
                                    .foregroundStyle(!item.isCompleted && date < timeline.date ? Color.orange : .secondary)
                            }
                        }
                    }.font(.system(size: 10))
                }.frame(maxWidth: .infinity, alignment: .leading)
            }.buttonStyle(.plain).accessibilityLabel("编辑：\(item.title)")
            Menu {
                Button("编辑") { controller.beginEditing(item) }
                Button(item.isCompleted ? "标记未完成" : "标记完成") { controller.toggle(item) }
                Divider()
                Button("删除", role: .destructive) { controller.delete(item) }
            } label: { Image(systemName: "ellipsis") }
            .menuStyle(.borderlessButton).menuIndicator(.hidden).fixedSize().frame(width: 18)
            .accessibilityLabel("更多操作：\(item.title)")
        }
        .padding(12)
        .background(.primary.opacity(0.035), in: RoundedRectangle(cornerRadius: 13))
    }
}
