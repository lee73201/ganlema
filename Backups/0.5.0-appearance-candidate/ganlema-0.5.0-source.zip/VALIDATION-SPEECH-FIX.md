> 后续 0.4.0 已完成编辑 UI 与自由缩放，且将用户在录音验收中确认保存的任务保留到正式库。当前结果见 [VALIDATION-EDITOR-UI.md](VALIDATION-EDITOR-UI.md)。

# 0.3.1 录音结束后文字丢失修复

日期：2026-10-25（Asia/Shanghai）。基于现有原生工程增量修复，版本 0.3.1 / build 5，Release，本机临时签名。

## 复现与根因

用户报告录音结束后文字框为空，且没有错误提示。修复前实际使用 macOS 合成的固定中文测试音经本机扬声器播放、麦克风录入：录音中出现了非空识别文字，点击结束录音后文字立即消失。该复现使用合成内容，不是用户私人录音。

原实现无条件将每次回调的 `bestTranscription.formattedString` 覆盖到 transcript，包括最终的空字符串。结束阶段只等 3 秒就取消任务；该阶段的识别错误没有显示。因此有用的实时文字会被最终空结果覆盖，用户只看到空框。

## 修复

- 引入 SpeechTranscriptBuffer。忽略 nil、空字符串和纯空白结果；有效的新结果仍可修正之前的文字，不通过拼接制造重复内容。
- 结束、服务错误、最终结果等待超时均保留已有文字；没有文字时明确显示失败原因，不静默回到“可解析”的成功状态。
- 最终等待延长至最多 15 秒；等待期间已有文字可通过“用当前文字解析”继续操作。
- 强引用保留 SFSpeechRecognizer 到本次会话结束，取消前先使回调会话失效，避免迟到回调修改下一次录音。
- 录音视图初次出现时读取已有 transcript，避免仅监听 onChange 而漏掉已经到达的结果。
- 启用系统标点；同时兼容语音识别省略标点时两个明确“日期+时刻”的任务边界。
- 本次无数据库 schema、持久化路径、Bundle ID 或通知权限修改。不保存录音文件，不把用户语音内容上传仓库。

## 验证结果

| 检查 | 实际结果 | 记录 |
| --- | --- | --- |
| Swift Package 测试 | 36/36 通过，退出码 0 | Validation/speech-fix-tests.log |
| Xcode FocusDock scheme Debug build + test，arm64 | TEST SUCCEEDED，36/36 通过，退出码 0 | Validation/speech-fix-xcode.log |
| Release 应用构建 | 成功，退出码 0 | Validation/speech-fix-build.log |
| 用户实际麦克风口述 | 用户授权后识别到非空文字，随后进入任务确认页；用户明确回复“我测试了一下可以用了” | 本次会话实际界面和用户回报 |
| 本地签名、plist 与 diff 空白检查 | 实际 codesign / plutil / git diff --check 验证 | 本次工具执行 |

新增五个回归测试：实时结果后收到空的 final/nil/纯空白仍保留文字；正常修正而不重复拼接；错误/超时保留可用部分结果；零文字不被当作成功；无标点语音仍拆出两条明确日期的待办。

旧版本的独立复现由代理执行；修复版本真实口述及进入确认由用户完成，明确区分两者。真实系统通知横幅送达不是本次验收范围，上一阶段的通知权限限制仍需另行验收。

用户实测发生于独立录音验收库。用户操作时不关闭确认页、不代点保存，也不把测试记录合并进真实库。该界面尚有用户确认内容时保持当前窗口；退出后正常打开 build/干了吗.app 使用原有真实库。临时验收库位置仅保存在本机 work/speech-fix/qa-location.txt，未上传。

应用备份和 SHA-256 位于 Backups/0.3.1-speech-fix。备份只含可执行应用，不含录音、截图、私人识别文本、任务数据库或偏好。

Apple 接口参考：[音频流识别及 endAudio](https://developer.apple.com/documentation/speech/sfspeechaudiobufferrecognitionrequest)。本次修复保留识别期间已经收到的有效文字，不将结束音频等同于收到最终结果。
